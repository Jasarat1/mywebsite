<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title>JSTUDIO</title>
	
    <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link href="css/nivo-lightbox.css" rel="stylesheet" />
	<link href="css/nivo-lightbox-theme/default/default.css" rel="stylesheet" type="text/css" />
	<link href="css/owl.carousel.css" rel="stylesheet" media="screen" />
    <link href="css/owl.theme.css" rel="stylesheet" media="screen" />
	<link href="css/flexslider.css" rel="stylesheet" />
	<link href="css/animate.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
	<link href="color/default.css" rel="stylesheet">

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
	
	<section id="intro" class="home-slide text-light">

		<!-- Carousel -->
    	<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
			<!-- Indicators -->
			<ol class="carousel-indicators">
			  	<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
			    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
			</ol>
			<!-- Wrapper for slides -->
			<div class="carousel-inner">
			    <div class="item active">
			    	<img src="img/1.jpg" alt="First slide">
                    <!-- Static Header -->
                    <div class="header-text hidden-xs">
                        <div class="col-md-12 text-center">
                           
                            <br>
                            <div class="">
                                 <a class="" href="#about"></a><a class="" href="#works"></a></div>
                        </div>
                    </div><!-- /header-text -->
			    </div>
			    <div class="item">
			    	<img src="img/2.jpg" alt="Second slide">
			    	<!-- Static Header -->
                    <div class="header-text hidden-xs">
                        <div class="col-md-12 text-center">
                            <h2>
                                
                           
                            <br>
                            <div class="">
                                 <a class="" href=""></a><a class="" href=""></a></div>
                        </div>
                    </div><!-- /header-text -->
			    </div>
			    <div class="item">
			    	<img src="img/3.jpg" alt="Third slide">
			    	<!-- Static Header -->
                    <div class="header-text hidden-xs">
                        <div class="col-md-12 text-center">
                            <h2>
                                
                            </h2>
                            <br>
                            <h3>
                            	<span></span>
                            </h3>
                            <br>
                            <div class="">
                                <a class="" href=""></a><a class="" href=""></a></div>
                        </div>
                    </div><!-- /header-text -->
			    </div>
			</div>
			<!-- Controls -->
			<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
		    	<span class="glyphicon glyphicon-chevron-left"></span>
			</a>
			<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
		    	<span class="glyphicon glyphicon-chevron-right"></span>
			</a>
		</div><!-- /carousel -->

	</section>
	<!-- /Section: intro -->
	
	
    <!-- Navigation -->
    <div id="navigation">
        <nav class="navbar navbar-custom" role="navigation">
                              <div class="container">
                                    <div class="row">
                                          <div class="col-md-2">
       

                    <div class="site-logo">
                                                            <a href="index.html" class="brand"><h style="font-family:AURULENT SANS"><h style="color:#800040">JSTUDIO</h></a>
                                                    </div>
                                          </div>
                                          

                                          <div class="col-md-10">



                         
                                                      <!-- Brand and toggle get grouped for better mobile display -->
                                          <div class="navbar-header">
                                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
                                                <i class="fa fa-bars"></i>
                                                </button>
                                          </div>
                                                      <!-- Collect the nav links, forms, and other content for toggling -->
                                                      <div class="collapse navbar-collapse" id="menu">
                                                            <ul class="nav navbar-nav navbar-right">
                                                                  <li class="active"><a href="#intro"><h style="color:Navy">Home</h></a></li>
                                                                 
																   <li><a href="#service"><h style="color:Navy">Services<h></a></li>
 <li><a href="#about"><h style="color:Navy">About<h></a></li>

                                                                  <li><a href="#works"><h style="color:Navy">Works<h></a></li>				                                                                  
                                                                  
                                                                  <li><a href="#contact"><h style="color:Navy">Contact<h></a></li>
                                                            </ul>
                                                      </div>
                                                      <!-- /.Navbar-collapse -->
                             
                                          </div>
                                    </div>
                              </div>
                              <!-- /.container -->
                        </nav>
    </div> 
    <!-- /Navigation -->  

<br></br>
<br></br>
<br></br>

	
	
	<!-- Section: services -->
    <section id="service" class="home-section color-dark bg-gray">
		<div class="container marginbot-50">
 <div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4 text-center">
        <h style="color:#1BBC9B"><marquee><i>We are At your service</i></marquee>		


            <h2 style="font-family:Cambria"><color:#800040">Our Services</h2>
            <hr>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 text-center">
            <div class="service-item">
              <img src="img/l.png" alt="banner">
              <h3 style="color:#EB5424">WEB DESIGN & DEVELOPMENT</h3>
              <p> We design clean,clever,and user friendly responsive web designs allowing visitors to have a pleasing and enjoyable visit. </p>
            </div>
          </div>
          <div class="col-md-4 text-center">
            <div class="service-item">
			  <img src="img/gp.png" alt="banner">
              <h3 style="color:#EB5424">BRAND IDENTITY & LOGO DESIGN</h3>
              <p>We address even the smallest details,be it stargazing,ideation,visualizing,designing or printing,we create effective communication and marketing tool that speak for your company or brand.Brand identity is great deal more compared to a skillfully designed logo or an appealing tagline.</p>
            </div>
          </div>
          <div class="col-md-4 text-center">
            <div class="service-item">
               <img src="img/res.png" alt="banner">
              <h3 style="color:#EB5424">SEARCH ENGINE OPTIMIZATION <h style="color:navy">(SEO)<h> </h3>
              <p>Search engine optimization (SEO) is the practice of increasing the quantity and quality of traffic to the website through organic search engine results..</p>
            </div>
          </div>
        </div>
      </div>
    </div>

			
                </div>
		</div>
            </div>
        </div>	

<br></br>
	
		</div>
		</div>
	</section>
	<!-- /Section: services -->





	<!-- Section: about -->
    <section id="about" class="home-section color-dark bg-white">
		<div class="container marginbot-50">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="">
					<div class="section-heading text-center">
					<h2 class="h-bold">About</h2>
					<div class="divider-header"></div>
					<p>Lead Developer Er Jasarat Amin </p>
					</div>
					</div>
				</div>
			</div>

		</div>

		<div class="container">

		
        <div class="row">
		
			<div class="col-md-6">
			    <img src="img/Jasarat.jpg" alt="" class="img-responsive" />
      
           </div>
			
            <div class="col-md-6">		
			<p>J_STUDIO is founded by Er Jasarat Amin in Oman,Muscat is a leading and only locally owned agencie in the Muscat ,U.A.E and in KASHMIR .</p>			
			<div class="progress progress-striped active">
			  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 96%">
				96% - WEB DESIGN/ DEVELOPMENT
			  </div>
			</div>
			<div class="progress progress-striped active">
			  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 90%">
				90% - SEO
			  </div>
			</div>
			<div class="progress progress-striped active">
			  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 97%">
			
				97% - BRANDING & LOGO
			  </div>

			</div>
			<div class="progress progress-striped active">
			  <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 92%">
				92% - JAVA/PHP/ANDROID
			  </div>
			</div>

            </div>

        </div>		
		</div>


	</section>
	<!-- /Section: about -->
            </div>

        </div>

    <section id="works" class="container spacer ">
   <section id="works" class="home-section color-dark text-center bg-white">
		<div class="container marginbot-50">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="wow flipInY" data-wow-offset="0" data-wow-delay="0.4s">
					<div class="section-heading text-center">
					<h2 class="h-bold">Portfolio</h2>
















					<div class="divider-header"></div>
				
					</div>
					</div>
				</div>
			</div>

		</div>

		</div>


     
</div>
    </div>
  </div>


<div class="container">

                <div class="heading-content text-center">
                    <h3>My Latest Works</h3>
          
                    </div>

                <!-- Example row of columns -->
                <div class="row">
                    <div class="portfolio-wrapper">
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="portfolio-item">
                                <a href="img/Jstudio.jpg" class="portfolio-img"><img src="img/Jstudio.jpg" alt="" /></a>
                            </div>
                       </div>

                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="portfolio-item">
                                <a href="img/Jasarat Amin.jpg" class="portfolio-img"><img src="img/Jasarat Amin.jpg" alt="" /></a>
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="portfolio-item">
                                <a href="img/Jsd.jpg" class="portfolio-img"> <img src="img/Jsd.jpg" alt="" /></a>
                              </div>
                        </div>

                    </div>
                </div>


            </div> <!-- /container -->       
        </section>

 


				<div class="container">
			<div class="row">
     
                    </div>
					</div>











  	</div>
                </div>
            </div>
		</div>

	</section>
	<!-- /Section: works -->

	<!-- Section: contact -->
    <section id="contact" class="home-section nopadd-bot color-dark bg-gray text-center">
		<div class="container marginbot-50 ">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="">
					<div class="section-heading text-center">
					<h2 class="h-bold">Contact us</h2>
					<div class="divider-header"></div>
					<p></p>
					</div>
					</div>
				</div>
			</div>

		</div>
		
		<div class="container">

			<div class="row marginbot-80">
<div class="col-md-8 col-md-offset-2">
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Feedback Form</title>
	<style type="text/css" media="screen">
		*{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: helvetica;
		}
		body{
			background-color: ;
		}
		.main{
			width: 500px;
			margin: 50px auto;
			border-radius: ;
			border:  ;
			border-left: ;
			box-shadow: ;
		}
		.info{
			width: 100%;
			background-color:black;
			padding: 7px;
			text-shadow: 1px 1px 1px #222;
			color: #fff;
			font-size: 20px;
		}
		.form-box{
			padding: 20px;
			background-image:url("color.jpg");
                        background-repeat:no-repeat;
		}
		label{
			color:Black;
			font-size: 18px;
		}
		.inp,.msg-box{
			width: 100%;
			padding: 10px;
			margin-top: 4px;
			margin-bottom: 5px;
			border-radius: 5px;
			border: 2px solid silver;
			font-weight: bold;
			color: black;
			border-right: ;
			border-leftlack: ;
			resize: none;
		}
		.msg-box{
			height: 80px;
		}
		.inp:focus,.msg-box:focus{
			outline: none;
			border: 2px solid NAVY;
			border-right: 5px solid NAVY;
			border-left: 5px solid NAVY;
		}
		.sub-btn{
			width: 100%;
			padding: 10px;
			border-radius: 5px;
			margin-top: 2px;
			border: none;
			background: linear-gradient(#dc143c,#800000);
			cursor: pointer;
			color: WHITE;
			font-size: 20px;
			text-shadow: 1px 1px 1px #444;
		}
		.sub-btn:hover{
			background: linear-gradient(#800000,#dc143c);
			opacity: 0.8;
			transition: all ease-out 0.2s;
		}
		.sub-btn:focus{
			outline: none;
		}
		@media(max-width: 720px){
			.main{
				width: 90%;
			}
		}
	</style>
</head>
<body>
	<div class="main">
		<div class="info"><h style="font-family:AURULENT SANS">Feel free to Contact Us</h></div>
		<form action="mail_handler.php" method="post" name="form" class="form-box">
			<label for="name">Name</label><br>
			<input type="text" name="name" class="inp" placeholder="Enter Your Name" required><br>
			<label for="email">Email ID</label><br>
			<input type="email" name="email" class="inp" placeholder="Enter Your Email" required><br>
			<label for="phone">Phone</label><br>
			<input type="tel" name="phone" class="inp" placeholder="Enter Your Phone" required><br>
			<label for="message">Message</label><br>
			<textarea name="msg" class="msg-box" placeholder="Enter Your Message Here..." required></textarea><br>
			<input type="submit" name="submit" value="Send" class="sub-btn">
		</form>
	</div>
</body>
</html>
			</div>	


		</div>

   
						</form>
				</div>
			</div>	


		</div>
	</section>
	<!-- /Section: contact -->


	<footer>
		<div class="container">
			<div class="row">
<a href="http://www.facebook.com/JB_Designs-1230511753760796/"</a>
 <img src="img/facebook.png" alt="" /></a>&nbsp;&nbsp;
&nbsp;&nbsp;
                 
                        
 <a href="http://instagram.com/jasarat_bhat">
                              <img src="img/insta.png" alt="" /></a>
				<div class="col-md-6 col-md-offset-3">
					
					<div class="text-center">
						<a href="#intro" class="totop"><i class="fa fa-angle-up fa-3x"></i></a>

						<p>J_Studio,Inc.1900 , INTENATIONAL. <br />
						&copy;Copyright 2018 -  Designed and Developed by <a href="http://bootstraptaste.com"><h style="color:gold">Jasarat Amin</h></a></p>
					</div>
				</div>
			</div>	
<marquee>
                   
		</div>
	</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>	 
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.sticky.js"></script>
	<script src="js/jquery.flexslider-min.js"></script>
    <script src="js/jquery.easing.min.js"></script>	
	<script src="js/jquery.scrollTo.js"></script>
	<script src="js/jquery.appear.js"></script>
	<script src="js/stellar.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/nivo-lightbox.min.js"></script>

    <script src="js/custom.js"></script>

</body>

</html>
